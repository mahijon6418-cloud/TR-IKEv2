plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.trikev2"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.trikev2"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
