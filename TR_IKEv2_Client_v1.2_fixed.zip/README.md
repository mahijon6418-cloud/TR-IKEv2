# TR IKEv2

سبک، ساده و شبیه کلاینت‌های IKEv2.

پیش‌فرض:
- Server: 149.50.208.98 (قابل ویرایش)
- Server Identity: pointtoserver.com
- Username: purevpn0s13269248 (در رابط به‌صورت مخفی نمایش داده می‌شود)
- Password: خالی و فقط هنگام اتصال توسط کاربر وارد می‌شود
- Profile: TR 🇹🇷
- DNS: 8.8.8.8

این نسخه از IKEv2 EAP Username/Password با API داخلی Android 11+ استفاده می‌کند.
رمز عبور در سورس قرار داده نشده است.

ساخت:
1. پروژه را در Android Studio باز کنید.
2. Gradle Sync.
3. Build APK.
4. برنامه را روی Android 11+ نصب کنید.
5. Password را وارد کنید و CONNECT را بزنید.
