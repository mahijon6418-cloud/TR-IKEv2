package com.example.trikev2

import android.app.Activity
import android.content.Intent
import android.net.Ikev2VpnProfile
import android.net.VpnManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var vpnManager: VpnManager
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val consentRequestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        vpnManager = getSystemService(VpnManager::class.java)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.connect).setOnClickListener { connectVpn() }
        findViewById<Button>(R.id.disconnect).setOnClickListener { disconnectVpn() }
    }

    private fun connectVpn() {
        if (Build.VERSION.SDK_INT < 30) {
            setStatus("● Android 11+ required", Color.YELLOW); return
        }
        val server = findViewById<EditText>(R.id.server).text.toString().trim()
        val identity = findViewById<EditText>(R.id.identity).text.toString().trim()
        val username = findViewById<EditText>(R.id.username).text.toString()
        val password = findViewById<EditText>(R.id.password).text.toString()

        if (server.isBlank() || identity.isBlank() || username.isBlank() || password.isBlank()) {
            setStatus("● Server / Identity / Username / Password required", Color.YELLOW)
            return
        }

        try {
            val profile = Ikev2VpnProfile.Builder(server, identity)
                .setAuthUsernamePassword(username, password, null)
                .setMetered(false)
                .build()

            val consentIntent = vpnManager.provisionVpnProfile(profile)
            if (consentIntent != null) {
                setStatus("● Waiting for VPN permission…", Color.YELLOW)
                startActivityForResult(consentIntent, consentRequestCode)
            } else {
                startVpn()
            }
        } catch (e: Exception) {
            setStatus("● Error: ${e.message}", Color.RED)
        }
    }

    private fun startVpn() {
        try {
            vpnManager.startProvisionedVpnProfileSession()
            setStatus("● Connecting…", Color.YELLOW)
        } catch (e: Exception) {
            setStatus("● Start error: ${e.message}", Color.RED)
        }
    }

    private fun disconnectVpn() {
        try {
            vpnManager.stopProvisionedVpnProfile()
            setStatus("● Disconnected", Color.LTGRAY)
        } catch (e: Exception) {
            setStatus("● Stop error: ${e.message}", Color.RED)
        }
    }

    private fun setStatus(text: String, color: Int) {
        status.text = text
        status.setTextColor(color)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == consentRequestCode) {
            if (resultCode == RESULT_OK) startVpn()
            else setStatus("● VPN permission cancelled", Color.YELLOW)
        }
    }
}
